<?php
    require("validar.php");
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        

        if ($data['operacion'] == 'seguir') {
            require("conn.php");
            $user2 = $data['usuario'];
            if ($user2 != $username) {
                $rescons = mysqli_query($conn, "SELECT * FROM seguidores WHERE seguidor = '$username' AND usuario = '$user2'");
                if ($rescons->num_rows == 1) {
                    $consultaDEL = "DELETE FROM seguidores WHERE seguidor = '$username' AND usuario = '$user2'";
                    mysqli_query($conn, $consultaDEL);
                    $res = array('estado' => 'Seguir');
                    echo json_encode($res);

                }else{
                    $consultaINS = "INSERT INTO `seguidores` (`id`, `seguidor`, `usuario`) VALUES (NULL, '$username', '$user2')";
                    mysqli_query($conn, $consultaINS);
                    $res = array('estado' => 'Siguiendo');
                    echo json_encode($res);
                }
            }
        }
        
    }