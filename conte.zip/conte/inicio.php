<?php

    require("validar.php");
    require("conn.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio | Outsgram</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/inicio.css">
</head>
<body>
    <?php include("menu/menu.php");?>

    <div id="container">
        <div id="fyp">

            <?php
                
                $sql = "SELECT * FROM publicaciones ORDER BY rand() LIMIT 10";
                $res = mysqli_query($conn, $sql);

                while ($rec = mysqli_fetch_assoc($res)) {
                    $idpub = $rec['id'];
                    $consRuta = mysqli_query($conn, "SELECT `path` FROM images WHERE idpub = '$idpub'");
                    $ruta = mysqli_fetch_assoc($consRuta)['path'];
                    $user2 = $rec['username'];
                    $consImgUser = mysqli_query($conn, "SELECT `path` FROM userimg WHERE username = '$user2'");
                    $imgUser = mysqli_fetch_assoc($consImgUser)['path'];
                    ?>

                    <div class="pub">
                        <div class="pub-header">
                            <div class="pub-header-user">
                                <img src="<?php echo $imgUser?>" alt="user-img" class="pub-user-img">
                                <p><?php echo $user2;?></p>
                            </div>
                            <?php
                                if ($user2 != $username) {
                                    $consSeg = "SELECT * FROM seguidores WHERE seguidor = '$username' AND usuario = '$user2'";
                                    if (mysqli_query($conn, $consSeg)->num_rows == 1) {?>
                                        <button data-user="<?php echo $user2;?>" class="pub-header-btn">
                                            Siguiendo
                                        </button>
                                    <?php } else{?>
                                        <button data-user="<?php echo $user2;?>" class="pub-header-btn">
                                            Seguir
                                        </button>
                                    <?php }
                                }
                            ?>
                            
                        </div>
                        <div class="pub-cont-img">
                            <img src="<?php echo $ruta;?>" class="pub-img">
                        </div>
                        <div class="pub-descript">
                            <p><?php echo $rec['descript'];?></p>
                        </div>
                    </div>

                    
            <?php }
            
            ?>            
            
        </div>
    </div>

    <script src="js/inicio.js"></script>
</body>
</html>