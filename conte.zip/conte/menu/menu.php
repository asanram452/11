<?php

    $consMenuImg = "SELECT `path` FROM userimg WHERE username = '$username'";
    $resMenuImg = mysqli_fetch_assoc(mysqli_query($conn, $consMenuImg))['path'];

?>

<head>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="menu/menu.css">
</head>

<div id="modal-menu">
    <div id="menu-modal-inter">
            <button id="menu-close-btn">
                <span class="material-symbols-outlined">close</span>
            </button>
            <h2>Menu</h2>
            <div id="cont-enl">
                <a href="inicio.php" class="menu-enl">Inicio</a>
                <a href="crear.php" class="menu-enl">Crear</a>
                <a href="cerrar.php" class="menu-enl">Cerrar sesión</a>
            </div>
            <hr id="menu-inter-hr">
            <div id="menu-inter-cont-p">

                <p id="menu-inter-p">Outsgram</p>

            </div>
    </div>
</div>

<nav id="menu">
    <div id="menu-inter">
        <div id="menu-user-profile">
            <img src="<?php echo $resMenuImg?>" id="menu-user-profile-img" alt="User-img">
        </div>
        <div id="menu-buttons">
            <button id="menu-modal-btn">
                <span class="material-symbols-outlined">menu</span>
            </button>
        </div>
    </div>
</nav>


<script src="menu/menu.js"></script>