const cerrarBtn = document.getElementById("menu-close-btn");
const menuInter = document.getElementById("menu-modal-inter");
const menu = document.getElementById("modal-menu");
const abrirBtn = document.getElementById("menu-modal-btn");



cerrarBtn.addEventListener("click", ()=>{
    menuInter.classList.remove("aparecer");
    menuInter.classList.add("desaparecer");


    setTimeout(() => {
        menu.style.display = 'none';
    }, 1000);
})

abrirBtn.addEventListener("click", ()=>{
    menu.style.display = 'flex';

    menuInter.classList.remove("desaparecer");
    menuInter.classList.add("aparecer");
    
    
})