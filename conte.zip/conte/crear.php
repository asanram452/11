<?php

    require("conn.php");
    require("validar.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear | Outsgram</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/crear.css">
</head>
<body>

    <?php include("menu/menu.php") ?>

    <div id="container">
        <form action="crear.php" method="post" id="fm" enctype="multipart/form-data">
            <?php
            
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                

                $descript = mysqli_escape_string($conn, $_POST['descript']);

                $sql = "INSERT INTO `publicaciones` (`id`, `username`, `descript`) VALUES (NULL, '$username', '$descript')";
                $res1 = mysqli_query($conn, $sql);

                if ($res1) {
                    $last_insert_id = mysqli_insert_id($conn);

                    $img = $_FILES["image"];
                    $nombreArchivo = $img["name"];
                    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
                    
                    if ($extension == "jpg" || $extension == "png" || $extension == "jepg" || $extension == "webp") {
                        $ruta_provisional = $img["tmp_name"];
                        $src = "imagenes/" . $last_insert_id . "." . $extension;
                        
                        if (move_uploaded_file($ruta_provisional, $src)) {
                            $sql2 = "INSERT INTO `images` (`id`, `idpub`, `path`) VALUES (NULL, '$last_insert_id', '$src')";
                            $res2 = mysqli_query($conn, $sql2);
                            
                            if ($res2) {
                                echo "<p class='success'>¡Publicación creada exitosamente!</p>";
                            } else {
                                echo "<p class='error'>Error al insertar la imagen en la base de datos.</p>";
                            }
                        } else {
                            echo "<p class='error'>Error al mover la imagen a la ubicación deseada.</p>";
                        }
                    }else{
                        echo "<p class='error'>El formato de imágen no es válido</p>";
                    }
                } else {
                    echo "<p class='error'>Error al insertar la publicación en la base de datos.</p>";
                }
            }
            ?>
            <h2>¡Publica!</h2>
            <label for="fm-image" id="label-image">Selecciona una imagen</label>
            <input type="file" name="image" id="fm-image">
            <textarea name="descript" class="fm-descript" placeholder="Descripción"></textarea>
            
            <button type="submit" id="fm-btn">
                Crear
            </button>
        </form>
    </div>
</body>
</html>
