<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <div id="container">
        <form id="fm" method="post" action="index.php">

            <?php
            
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    require("conn.php");

                    $username = mysqli_escape_string($conn, $_POST['username']);
                    $psd = mysqli_escape_string($conn, $_POST['psd']);

                    $SLquery = "SELECT * FROM usuarios WHERE username = '$username' AND psd = '$psd'";
                    if (mysqli_query($conn, $SLquery)->num_rows == 1) {
                        session_start();
                        $_SESSION['username'] = $username;

                        header("Location: inicio.php");
                    }else{?>

                        <div id="login-error">
                            <p>Datos inválidos</p>
                        </div>
                        
                    <?php }
                }
            
            ?>

            

            <h2>Log in</h2>
            <input type="text" name="username" class="fm-input" placeholder="Usuario">
            <input type="password" name="psd" class="fm-input" placeholder="Contraseña">
            <button type="submit" id="fm-btn">
                Ingresar
            </button>
        </form>
    </div>
</body>
</html>