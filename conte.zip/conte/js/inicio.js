let btn_seg = document.querySelectorAll(".pub-header-btn");

btn_seg.forEach(elemento => {
    elemento.addEventListener('click', () => {
        const options = {
            method: 'post',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                operacion: 'seguir',
                usuario: elemento.dataset.user
            })
        };

        fetch("operaciones.php", options)
            .then(data => data.json())
            .then(data => {
                elemento.innerHTML = data.estado;
            })
            .catch(error => {
                alert("Error");
            });
    });
});
